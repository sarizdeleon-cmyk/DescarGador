plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.leon.descargador"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.leon.descargador"
        minSdk = 29
        targetSdk = 34
        versionCode = 4
        versionName = "1.3"
        // Solo celulares reales (64 y 32 bits): el APK pesa menos que incluyendo emuladores
        ndk {
            abiFilters += listOf("arm64-v8a", "armeabi-v7a")
        }
    }

    // Llave fija incluida en el proyecto: asi cada version nueva se instala encima de la anterior
    signingConfigs {
        create("leon") {
            storeFile = file("leon.keystore")
            storePassword = "descargador"
            keyAlias = "leon"
            keyPassword = "descargador"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("leon")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }

    // yt-dlp y ffmpeg viajan como bibliotecas nativas que Android debe extraer al instalar
    packaging {
        jniLibs {
            useLegacyPackaging = true
        }
        resources {
            excludes += setOf("/META-INF/{AL2.0,LGPL2.1}", "META-INF/DEPENDENCIES", "META-INF/LICENSE*", "META-INF/NOTICE*")
        }
    }

    lint {
        checkReleaseBuilds = false
        abortOnError = false
    }
}

dependencies {
    implementation("io.github.junkfood02.youtubedl-android:library:0.18.1")
    implementation("io.github.junkfood02.youtubedl-android:ffmpeg:0.18.1")
}
