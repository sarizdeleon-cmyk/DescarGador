package com.leon.descargador

import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONObject

/**
 * "Ver ahora" para videos de YouTube y Dailymotion: yt-dlp averigua el link directo del video (un solo archivo con
 * imagen y sonido) y la interfaz lo reproduce en su reproductor. Solo se reproduce un video a la vez.
 */
object Directo {
    private val RE_YT = Regex("^[A-Za-z0-9_-]{11}$")
    private val RE_DM = Regex("^[A-Za-z0-9]{4,16}$")

    /** Link publico del video, o null si el id no tiene la forma correcta de esa pagina. */
    fun urlDe(fuente: String, id: String): String? = when (fuente) {
        "yt" -> if (RE_YT.matches(id)) "https://www.youtube.com/watch?v=$id" else null
        "dm" -> if (RE_DM.matches(id)) "https://www.dailymotion.com/video/$id" else null
        else -> null
    }

    private val candado = Any()
    private var token = 0
    private var estado = "inactiva"      // inactiva | buscando | lista | error
    private var mensaje = ""
    private var url = ""

    fun reproducir(fuente: String, id: String): Int {
        val mio = synchronized(candado) {
            token += 1
            estado = "buscando"
            mensaje = ""
            url = ""
            token
        }
        Thread { resolver(mio, fuente, id) }.start()
        return mio
    }

    fun json(): JSONObject {
        val o = JSONObject()
        synchronized(candado) {
            o.put("token", token)
            o.put("estado", estado)
            o.put("mensaje", mensaje)
            o.put("url", url)
        }
        return o
    }

    private fun resolver(mio: Int, fuente: String, id: String) {
        var estadoFinal = "lista"
        var mensajeFinal = ""
        var enlace = ""
        try {
            val pagina = urlDe(fuente, id)
            if (pagina == null) {
                estadoFinal = "error"
                mensajeFinal = "No se pudo abrir ese video."
            } else if (!Motor.esperarListo(90000)) {
                estadoFinal = "error"
                mensajeFinal = "La app todavía se está preparando (solo tarda la primera vez). Intenta de nuevo en unos segundos."
            } else {
                val enlaces = enlacesDirectos(pagina)
                when {
                    enlaces.isEmpty() -> {
                        estadoFinal = "error"
                        mensajeFinal = "No se pudo abrir ese video. Puede ser privado o tener restricción de edad. Prueba descargándolo."
                    }
                    enlaces.size > 1 -> {
                        estadoFinal = "error"
                        mensajeFinal = "Este video no tiene una versión con imagen y sonido juntos para verla aquí. Puedes descargarlo."
                    }
                    else -> enlace = enlaces[0]
                }
            }
        } catch (e: Exception) {
            estadoFinal = "error"
            mensajeFinal = "No se pudo abrir ese video aquí. Revisa tu conexión, o prueba descargándolo."
        }
        synchronized(candado) {
            if (mio != token) return          // ya se pidio otro video
            estado = estadoFinal
            mensaje = mensajeFinal
            url = enlace
        }
    }

    /**
     * Pide a yt-dlp solo el link: primero un mp4 que ya trae imagen y sonido por https (en YouTube suele ser de calidad
     * normal, 360p o 720p), si no cualquier archivo asi y, al final, lo mejor que haya (por ejemplo una lista HLS de
     * Dailymotion). La calidad maxima solo se consigue descargando, porque ahi se unen imagen y sonido por separado.
     */
    private fun enlacesDirectos(pagina: String): List<String> {
        val req = YoutubeDLRequest(pagina)
        req.addOption("--no-playlist")
        req.addOption("--no-warnings")
        req.addOption("--no-colors")
        req.addOption("--socket-timeout", "20")
        req.addOption("-f", "b[ext=mp4][protocol=https]/b[protocol=https]/b")
        req.addOption("-g")
        val salida = YoutubeDL.getInstance().execute(req, "ver-" + System.nanoTime()) { _, _, _ -> }.out
        return salida.lines().map { it.trim() }.filter { it.startsWith("https://") && it.length <= 4096 }
    }
}
