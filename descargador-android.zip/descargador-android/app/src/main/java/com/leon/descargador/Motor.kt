package com.leon.descargador

import android.content.ContentValues
import android.content.Context
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import com.yausername.ffmpeg.FFmpeg
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

/**
 * Cerebro de la app: lleva la cuenta de las descargas y atiende las mismas "rutas" que el
 * servidor de la version de computadora, para poder reutilizar la misma interfaz (index.html).
 */
object Motor {
    const val AUTOR = "Aldo Leon"
    const val WHATSAPP = "+52 992 108 3800"
    const val FIRMA = "Leon"          // el archivo queda como: <titulo del video> by Leon.mp4

    private const val TAG = "Descargador"
    private val ACTIVOS = setOf("en cola", "descargando", "uniendo", "convirtiendo")
    private val RE_URL = Regex("^https?://\\S+$")
    private val RE_PCT = Regex("""\[download\]\s+(\d+(?:\.\d+)?)%""")
    private val RE_VEL = Regex("""\bat\s+(\S+/s)""")
    private val RE_ETA = Regex("""ETA\s+(\S+)""")
    private val RE_DEST = Regex("""^\[download\] Destination: (.+)$""")
    private val RE_BPS = Regex("""^([\d.]+)\s*([KMGT]?i?B)/s$""")
    private val BYTES = mapOf(
        "B" to 1.0, "KB" to 1e3, "MB" to 1e6, "GB" to 1e9,
        "KiB" to 1024.0, "MiB" to 1048576.0, "GiB" to 1073741824.0
    )

    class Tarea(val url: String, val modo: String) {
        val id: String = UUID.randomUUID().toString().substring(0, 8)
        @Volatile var estado = "en cola"
        @Volatile var pct = 0.0
        @Volatile var velocidad = ""
        @Volatile var bps = 0.0
        @Volatile var eta = ""
        @Volatile var titulo = ""
        @Volatile var archivo = ""
        @Volatile var mensaje = ""
        @Volatile var detalle = ""

        fun json(): JSONObject {
            val o = JSONObject()
            o.put("id", id)
            o.put("url", url)
            o.put("modo", modo)
            o.put("estado", estado)
            o.put("pct", pct)
            o.put("velocidad", velocidad)
            o.put("bps", if (estado == "descargando") bps else 0.0)
            o.put("eta", eta)
            o.put("titulo", titulo)
            o.put("archivo", archivo)
            o.put("mensaje", mensaje)
            return o
        }
    }

    private lateinit var app: Context
    @Volatile private var iniciado = false
    @Volatile private var listo = false
    @Volatile private var mensajePrep = "Iniciando…"
    @Volatile private var errorPrep: String? = null
    private val tareas = CopyOnWriteArrayList<Tarea>()
    private val ejecutor = Executors.newSingleThreadExecutor()

    // ------------------------------------------------------------------
    // Preparacion: yt-dlp (con su Python) y ffmpeg vienen dentro de la app
    // ------------------------------------------------------------------
    @Synchronized
    fun iniciar(contexto: Context) {
        if (iniciado) return
        iniciado = true
        app = contexto.applicationContext
        Thread { preparar() }.start()
    }

    fun reintentar() {
        if (errorPrep != null) Thread { preparar() }.start()
    }

    private fun preparar() {
        errorPrep = null
        listo = false
        mensajePrep = "Preparando la app (solo tarda la primera vez)…"
        try {
            YoutubeDL.getInstance().init(app)
            FFmpeg.getInstance().init(app)
        } catch (e: Exception) {
            Log.e(TAG, "No se pudo preparar yt-dlp/ffmpeg", e)
            errorPrep = "No se pudo preparar la app: " + (e.message ?: e.toString())
            return
        }
        listo = true
        mensajePrep = "Listo"
        actualizarYtdlp(false)          // yt-dlp se actualiza solo, como maximo una vez al dia
    }

    /**
     * Baja la ultima version de yt-dlp (los sitios cambian seguido y la que viene en el APK se vuelve vieja).
     * Se llama por reflexion para no depender de como se llame exactamente el canal "estable" en cada
     * version de la biblioteca.
     */
    @Synchronized
    fun actualizarYtdlp(forzar: Boolean): Boolean {
        val prefs = app.getSharedPreferences("motor", Context.MODE_PRIVATE)
        val ahora = System.currentTimeMillis()
        if (!forzar && ahora - prefs.getLong("ultima_actualizacion", 0L) < 24L * 3600L * 1000L) return false
        return try {
            val canal = Class.forName("com.yausername.youtubedl_android.YoutubeDL\$UpdateChannel")
            val estable = canalEstable(canal)
            val ydl = YoutubeDL.getInstance()
            if (estable != null) {
                YoutubeDL::class.java.getMethod("updateYoutubeDL", Context::class.java, canal).invoke(ydl, app, estable)
            } else {
                YoutubeDL::class.java.getMethod("updateYoutubeDL", Context::class.java).invoke(ydl, app)
            }
            prefs.edit().putLong("ultima_actualizacion", ahora).apply()
            true
        } catch (e: Exception) {
            Log.w(TAG, "No se pudo actualizar yt-dlp", e)
            false
        }
    }

    private fun canalEstable(canal: Class<*>): Any? {
        for (nombre in listOf("STABLE", "_STABLE")) {
            try {
                return canal.getField(nombre).get(null)
            } catch (e: Exception) {
                // probar la siguiente forma
            }
        }
        for (sub in canal.declaredClasses) {
            if (sub.simpleName.equals("_STABLE", true) || sub.simpleName.equals("STABLE", true)) {
                try {
                    return sub.getField("INSTANCE").get(null)
                } catch (e: Exception) {
                    // probar la siguiente forma
                }
            }
        }
        return canal.enumConstants?.firstOrNull { it.toString().contains("STABLE", true) }
    }

    // ------------------------------------------------------------------
    // Descargas
    // ------------------------------------------------------------------
    fun descargar(urls: List<String>, modo: String): JSONObject {
        val buenas = ArrayList<String>()
        val malas = ArrayList<String>()
        for (u in urls.take(30)) {
            val x = u.trim()
            if (x.length <= 2000 && RE_URL.matches(x)) buenas.add(x) else malas.add(x)
        }
        synchronized(this) {
            val nuevas = buenas.map { Tarea(it, modo) }
            tareas.addAll(nuevas)
            if (nuevas.isNotEmpty()) DescargasService.arrancar(app)
            for (t in nuevas) ejecutor.execute { trabajar(t) }
        }
        val o = JSONObject()
        o.put("ok", buenas.isNotEmpty())
        o.put("creadas", buenas.size)
        o.put("rechazadas", JSONArray(malas.take(5)))
        return o
    }

    private fun trabajar(t: Tarea) {
        try {
            if (t.estado == "cancelado") return
            while (!listo && errorPrep == null) Thread.sleep(500)
            if (t.estado == "cancelado") return
            if (!listo) {
                t.estado = "error"
                t.mensaje = "La app no está lista. Usa Reintentar."
                return
            }
            var ok = correr(t)
            if (!ok && t.estado != "cancelado") {
                val d = t.detalle.lowercase()
                val permanente = listOf("unsupported url", "private", "unavailable").any { d.contains(it) }
                if (!permanente) {
                    actualizarYtdlp(true)          // un sitio que cambio: actualizar yt-dlp y reintentar una vez
                    ok = correr(t)
                }
            }
            if (!ok && t.estado != "cancelado") {
                t.estado = "error"
                t.mensaje = traducirError(t.detalle)
            }
        } finally {
            finTarea()
        }
    }

    private fun correr(t: Tarea): Boolean {
        val dir = File(app.cacheDir, "trabajo/" + t.id)
        dir.deleteRecursively()
        dir.mkdirs()
        t.pct = 0.0
        t.velocidad = ""
        t.bps = 0.0
        t.eta = ""
        t.detalle = ""
        t.estado = "descargando"
        try {
            val req = YoutubeDLRequest(t.url)
            req.addOption("--no-playlist")
            req.addOption("--no-colors")
            req.addOption("-o", dir.absolutePath + "/%(title).150B by " + FIRMA + ".%(ext)s")
            if (t.modo == "audio") {
                req.addOption("-f", "ba/b")
                req.addOption("-x")
                req.addOption("--audio-format", "mp3")
                req.addOption("--audio-quality", "0")
            } else {
                req.addOption("-f", "bv*+ba/b")
                req.addOption("-S", "res,ext:mp4:m4a")
                req.addOption("--merge-output-format", "mp4")
            }
            YoutubeDL.getInstance().execute(req, t.id) { _, _, linea -> procesarLinea(t, linea) }

            if (t.estado == "cancelado") return false
            val archivo = dir.listFiles()
                ?.filter { it.isFile && !it.name.endsWith(".part") && !it.name.endsWith(".ytdl") }
                ?.maxByOrNull { it.length() }
            if (archivo == null) {
                t.detalle = "No se encontró el archivo descargado."
                return false
            }
            val nombre = guardarEnDescargas(archivo)
            t.archivo = nombre
            t.titulo = tituloDe(archivo.name)
            t.pct = 100.0
            t.velocidad = ""
            t.eta = ""
            t.bps = 0.0
            t.estado = "listo"
            return true
        } catch (e: Exception) {
            if (t.estado != "cancelado") {
                Log.w(TAG, "Fallo la descarga", e)
                t.detalle = e.message ?: e.toString()
            }
            return false
        } finally {
            dir.deleteRecursively()
        }
    }

    private fun procesarLinea(t: Tarea, texto: String?) {
        val linea = texto ?: return
        if (t.estado == "cancelado") return
        val m = RE_PCT.find(linea)
        if (m != null) {
            t.pct = m.groupValues[1].toDoubleOrNull() ?: t.pct
            val v = RE_VEL.find(linea)?.groupValues?.get(1) ?: ""
            val e = RE_ETA.find(linea)?.groupValues?.get(1) ?: ""
            t.velocidad = v
            t.bps = bytesPorSegundo(v)
            t.eta = if (e == "Unknown") "" else e
            t.estado = "descargando"
            return
        }
        if (linea.startsWith("[Merger]")) {
            t.estado = "uniendo"
            t.velocidad = ""
            t.eta = ""
            t.bps = 0.0
            return
        }
        if (linea.startsWith("[ExtractAudio]")) {
            t.estado = "convirtiendo"
            t.velocidad = ""
            t.eta = ""
            t.bps = 0.0
            return
        }
        val d = RE_DEST.find(linea)
        if (d != null && t.titulo.isEmpty()) t.titulo = tituloDe(d.groupValues[1])
        if (linea.startsWith("ERROR:")) t.detalle = linea.substring(6).trim()
    }

    private fun bytesPorSegundo(texto: String): Double {
        val m = RE_BPS.find(texto) ?: return 0.0
        val numero = m.groupValues[1].toDoubleOrNull() ?: return 0.0
        return numero * (BYTES[m.groupValues[2]] ?: 0.0)
    }

    private fun tituloDe(ruta: String): String {
        var n = ruta.substringAfterLast('/').substringAfterLast('\\')
        if (n.contains('.')) n = n.substringBeforeLast('.')
        n = n.replace(Regex("""\.f\d+$"""), "")
        val sufijo = " by $FIRMA"
        if (n.endsWith(sufijo)) n = n.dropLast(sufijo.length)
        return n
    }

    private fun traducirError(detalle: String): String {
        val d = detalle.lowercase()
        return when {
            "unsupported url" in d -> "Ese link no es de un sitio compatible."
            "private" in d || "sign in" in d || "log in" in d || "login" in d -> "El video es privado o pide iniciar sesión."
            "unavailable" in d || "removed" in d || "does not exist" in d || "404" in d -> "El video no está disponible o fue borrado."
            "ffmpeg" in d || "ffprobe" in d -> "No se pudo procesar el video (ffmpeg)."
            detalle.isBlank() -> "No se pudo descargar."
            detalle.length > 200 -> detalle.take(200) + "..."
            else -> detalle
        }
    }

    /** Copia el archivo terminado a la carpeta Descargas del celular y devuelve el nombre con que quedo. */
    private fun guardarEnDescargas(origen: File): String {
        val mime = when (origen.extension.lowercase()) {
            "mp4" -> "video/mp4"
            "mp3" -> "audio/mpeg"
            "m4a" -> "audio/mp4"
            "webm" -> "video/webm"
            "mkv" -> "video/x-matroska"
            else -> "application/octet-stream"
        }
        val valores = ContentValues()
        valores.put(MediaStore.MediaColumns.DISPLAY_NAME, origen.name)
        valores.put(MediaStore.MediaColumns.MIME_TYPE, mime)
        valores.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
        valores.put(MediaStore.MediaColumns.IS_PENDING, 1)
        val resolver = app.contentResolver
        val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, valores)
            ?: throw IOException("No se pudo crear el archivo en Descargas.")
        try {
            val salida = resolver.openOutputStream(uri) ?: throw IOException("No se pudo escribir en Descargas.")
            salida.use { s -> origen.inputStream().use { entrada -> entrada.copyTo(s) } }
            val listoParaVer = ContentValues()
            listoParaVer.put(MediaStore.MediaColumns.IS_PENDING, 0)
            resolver.update(uri, listoParaVer, null, null)
        } catch (e: Exception) {
            resolver.delete(uri, null, null)
            throw e
        }
        var nombre = origen.name
        resolver.query(uri, arrayOf(MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) nombre = c.getString(0)
        }
        return nombre
    }

    fun cancelar(id: String) {
        val t = tareas.firstOrNull { it.id == id } ?: return
        if (t.estado in ACTIVOS) {
            t.estado = "cancelado"
            try {
                YoutubeDL.getInstance().destroyProcessById(t.id)
            } catch (e: Exception) {
                Log.w(TAG, "No se pudo detener el proceso", e)
            }
        }
    }

    fun limpiar() {
        tareas.removeIf { it.estado !in ACTIVOS }
    }

    private fun finTarea() {
        synchronized(this) {
            if (tareas.none { it.estado in ACTIVOS }) DescargasService.detener(app)
        }
    }

    // ------------------------------------------------------------------
    // Lo que ve la interfaz
    // ------------------------------------------------------------------
    private fun estadoJson(): JSONObject {
        val o = JSONObject()
        o.put("listo", listo)
        o.put("mensaje", mensajePrep)
        o.put("progreso", JSONObject.NULL)
        o.put("error", errorPrep ?: JSONObject.NULL)
        o.put("aviso", JSONObject.NULL)
        o.put("ffmpeg", true)
        o.put("escritorio", "Descargas")
        o.put("autor", AUTOR)
        o.put("whatsapp", WHATSAPP)
        val lista = JSONArray()
        for (t in tareas.takeLast(60)) lista.put(t.json())
        o.put("tareas", lista)
        o.put("prueba", Medidor.json())
        return o
    }

    private fun ok(): JSONObject {
        val o = JSONObject()
        o.put("ok", true)
        return o
    }

    /** Atiende una "peticion" de la interfaz (equivale a las rutas /api/... del servidor de escritorio). */
    fun api(ruta: String, cuerpo: String, actividad: MainActivity?): JSONObject {
        val datos = try {
            if (cuerpo.isBlank()) JSONObject() else JSONObject(cuerpo)
        } catch (e: Exception) {
            JSONObject()
        }
        return when (ruta) {
            "/api/estado" -> estadoJson()
            "/api/descargar" -> {
                val lista = ArrayList<String>()
                val arr = datos.optJSONArray("urls")
                if (arr != null) for (i in 0 until arr.length()) lista.add(arr.optString(i))
                descargar(lista, if (datos.optString("modo") == "audio") "audio" else "video")
            }
            "/api/cancelar" -> {
                cancelar(datos.optString("id"))
                ok()
            }
            "/api/limpiar" -> {
                limpiar()
                ok()
            }
            "/api/abrir-carpeta" -> {
                actividad?.abrirDescargas()
                ok()
            }
            "/api/reintentar" -> {
                reintentar()
                ok()
            }
            "/api/medir-velocidad" -> {
                val r = ok()
                r.put("iniciada", Medidor.iniciar())
                r
            }
            "/api/salir" -> {
                actividad?.cerrar()
                ok()
            }
            else -> {
                val r = JSONObject()
                r.put("ok", false)
                r.put("error", "no encontrado")
                r
            }
        }
    }
}
