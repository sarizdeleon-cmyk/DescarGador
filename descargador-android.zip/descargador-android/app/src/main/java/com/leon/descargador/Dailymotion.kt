package com.leon.descargador

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder

/**
 * Busca en Dailymotion videos "completa en español" de mas de 60 minutos, con las mismas reglas que Youtube.kt.
 * Usa la API publica de Dailymotion (sin cuenta). Si Dailymotion no responde, solo falla esta fuente: los
 * resultados de YouTube siguen saliendo (la interfaz junta las dos).
 */
object Dailymotion {
    internal var base = "https://api.dailymotion.com"      // las pruebas lo apuntan a un servidor local
    private const val POR_PAGINA = 50
    private const val MAX_PAGINAS = 3
    private const val QUIERO_AL_MENOS = 12
    private const val MIN_SEGUNDOS = 3600.0
    private const val MAX_BYTES = 4 * 1024 * 1024
    private const val BASE_BUSQUEDA = "completa en español"
    private const val MAX_TITULO = 160
    private val RE_ID = Regex("^[A-Za-z0-9]{4,16}$")
    private val RE_ESPACIOS = Regex("""\s+""")
    private val RE_RARO = Regex("""[^\p{L}\p{N} ]""")

    private val candado = Any()
    private var token = 0
    private var estado = "inactiva"          // inactiva | buscando | lista | error
    private var mensaje = ""
    private var siguiente = 0                // paginas de Dailymotion ya revisadas (donde sigue "Ver más")
    private var hayMas = false
    private var resultados: List<Youtube.Video> = emptyList()

    /** desde = 0 empieza; para "Ver más" se manda el "siguiente" de la respuesta anterior. */
    fun buscar(texto: String, desde: Int): Int {
        val d = desde.coerceIn(0, 200)
        val mio = synchronized(candado) {
            token += 1
            estado = "buscando"
            mensaje = ""
            resultados = emptyList()
            hayMas = false
            siguiente = d
            token
        }
        Thread { trabajar(mio, texto, d) }.start()
        return mio
    }

    fun json(): JSONObject {
        val o = JSONObject()
        synchronized(candado) {
            o.put("token", token)
            o.put("estado", estado)
            o.put("mensaje", mensaje)
            o.put("siguiente", siguiente)
            o.put("hay_mas", hayMas)
            val arr = JSONArray()
            for (v in resultados) arr.put(v.json())
            o.put("resultados", arr)
        }
        return o
    }

    private fun trabajar(mio: Int, texto: String, desde: Int) {
        var nuevoEstado = "lista"
        var nuevoMensaje = ""
        var lista: List<Youtube.Video> = emptyList()
        var paginas = desde
        var quedan = false
        try {
            val vistos = HashSet<String>()
            val acumulado = ArrayList<Youtube.Video>()
            var revisadas = 0
            quedan = true
            while (revisadas < MAX_PAGINAS && acumulado.size < QUIERO_AL_MENOS && quedan) {
                val cuerpo = pedirPagina(texto, paginas + 1)
                val o = JSONObject(cuerpo)
                val elementos = o.optJSONArray("list")
                acumulado.addAll(filtrar(elementos, vistos))
                paginas += 1
                revisadas += 1
                quedan = o.optBoolean("has_more", false) && (elementos?.length() ?: 0) > 0
            }
            lista = acumulado
        } catch (e: SocketTimeoutException) {
            nuevoEstado = "error"
            nuevoMensaje = "Dailymotion tardó demasiado en responder."
        } catch (e: Exception) {
            nuevoEstado = "error"
            nuevoMensaje = "Dailymotion no respondió bien."
        }
        synchronized(candado) {
            if (mio != token) return          // ya hay una busqueda mas nueva: esta se descarta
            estado = nuevoEstado
            mensaje = nuevoMensaje
            resultados = lista
            siguiente = paginas
            hayMas = nuevoEstado == "lista" && quedan
        }
    }

    fun consulta(texto: String): String {
        val limpio = RE_ESPACIOS.replace(RE_RARO.replace(texto, " "), " ").trim().take(80).trim()
        return if (limpio.isEmpty()) BASE_BUSQUEDA else "$limpio $BASE_BUSQUEDA"
    }

    /** Pagina 1 en adelante. "longer_than" (minutos) deja la mayor parte del trabajo a Dailymotion; igual se vuelve a revisar aqui. */
    fun urlDePagina(texto: String, pagina: Int, conFiltroDeDuracion: Boolean = true): String =
        base + "/videos?search=" + URLEncoder.encode(consulta(texto), "UTF-8") +
            (if (conFiltroDeDuracion) "&longer_than=60" else "") +
            "&limit=" + POR_PAGINA + "&page=" + pagina +
            "&fields=" + URLEncoder.encode("id,title,duration,owner.screenname,views_total,thumbnail_360_url", "UTF-8")

    private fun pedirPagina(texto: String, pagina: Int): String {
        try {
            return pedir(urlDePagina(texto, pagina, true))
        } catch (e: IOException) {
            // si Dailymotion no acepta el filtro de duracion (error 400), se intenta sin el: abajo se filtra por duracion igual
            if (e.message?.contains("400") == true) return pedir(urlDePagina(texto, pagina, false))
            throw e
        }
    }

    private fun pedir(direccion: String): String {
        val c = URL(direccion).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"
            c.connectTimeout = 12000
            c.readTimeout = 20000
            c.useCaches = false
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (descargador-android)")
            c.setRequestProperty("Accept", "application/json")
            val codigo = c.responseCode
            if (codigo != 200) throw IOException("Dailymotion respondió con error $codigo.")
            val salida = ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            c.inputStream.use { entrada ->
                while (true) {
                    val n = entrada.read(buffer)
                    if (n < 0) break
                    salida.write(buffer, 0, n)
                    if (salida.size() > MAX_BYTES) throw IOException("La respuesta de Dailymotion es demasiado grande.")
                }
            }
            return salida.toString("UTF-8")
        } finally {
            c.disconnect()
        }
    }

    /** El canal viene como "owner.screenname" (clave con punto) o dentro de "owner": se aceptan las dos formas. */
    private fun canalDe(e: JSONObject): String {
        val plano = Youtube.texto(e, "owner.screenname")
        if (plano.isNotEmpty()) return plano
        return e.optJSONObject("owner")?.let { Youtube.texto(it, "screenname") } ?: ""
    }

    /** Mas de 60 minutos y titulo que diga "completa/completo", sin repetidos. */
    fun filtrar(elementos: JSONArray?, vistos: MutableSet<String>): List<Youtube.Video> {
        val salida = ArrayList<Youtube.Video>()
        if (elementos == null) return salida
        for (i in 0 until elementos.length()) {
            val e = elementos.optJSONObject(i) ?: continue
            val id = Youtube.texto(e, "id")
            if (!RE_ID.matches(id) || id in vistos) continue
            val duracion = Youtube.numero(e, "duration") ?: continue
            if (duracion <= MIN_SEGUNDOS) continue
            val titulo = Youtube.texto(e, "title")
            if (titulo.isEmpty() || !Youtube.normalizar(titulo).contains("complet")) continue
            val vistas = Youtube.numero(e, "views_total")?.toLong() ?: 0L
            vistos.add(id)
            val miniatura = Youtube.texto(e, "thumbnail_360_url").take(500)
            salida.add(Youtube.Video("dm", id, titulo.take(MAX_TITULO), canalDe(e).take(80), duracion.toLong(), vistas, miniatura))
        }
        return salida
    }
}
