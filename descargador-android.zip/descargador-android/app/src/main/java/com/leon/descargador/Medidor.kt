package com.leon.descargador

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.util.Random
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLongArray
import kotlin.math.roundToInt

/**
 * Medidor de velocidad de internet (ping, bajada y subida).
 * Usa el servicio publico de pruebas de Cloudflare: /__down?bytes=N, /__up y /__down?bytes=0,
 * con varias conexiones en paralelo. Es la misma logica del medidor de la version de computadora.
 */
object Medidor {
    private const val BASE = "https://speed.cloudflare.com"
    private const val SEG_BAJADA = 8.0
    private const val SEG_SUBIDA = 6.0
    private const val CONEXIONES = 4
    private const val TAM_BAJADA = 25000000
    private const val TAM_SUBIDA = 10000000

    private class ErrorMedicion(mensaje: String) : Exception(mensaje)

    private val ocupado = AtomicBoolean(false)
    @Volatile private var fase = "inactiva"
    @Volatile private var actual: Double? = null
    @Volatile private var ping: Int? = null
    @Volatile private var bajada: Double? = null
    @Volatile private var subida: Double? = null
    @Volatile private var progreso = 0.0
    @Volatile private var medidoEn: Double? = null
    @Volatile private var mensaje = ""

    fun json(): JSONObject {
        val o = JSONObject()
        o.put("fase", fase)
        o.put("actual", actual ?: JSONObject.NULL)
        o.put("ping", ping ?: JSONObject.NULL)
        o.put("bajada", bajada ?: JSONObject.NULL)
        o.put("subida", subida ?: JSONObject.NULL)
        o.put("progreso", progreso)
        o.put("medido_en", medidoEn ?: JSONObject.NULL)
        o.put("mensaje", mensaje)
        return o
    }

    /** Empieza una medicion en segundo plano. Devuelve false si ya hay una en curso. */
    fun iniciar(): Boolean {
        if (!ocupado.compareAndSet(false, true)) return false
        fase = "ping"
        actual = null
        ping = null
        bajada = null
        subida = null
        progreso = 2.0
        mensaje = ""
        Thread { medir() }.start()
        return true
    }

    private fun medir() {
        try {
            ping = medirPing()
            progreso = 10.0
            bajada = faseBajada(SEG_BAJADA, 10.0, 55.0)
            var aviso = ""
            try {
                subida = faseSubida(SEG_SUBIDA, 55.0, 98.0)
            } catch (e: Exception) {
                aviso = "No se pudo medir la subida."
            }
            fase = "lista"
            actual = null
            progreso = 100.0
            medidoEn = System.currentTimeMillis() / 1000.0
            mensaje = aviso
        } catch (e: Exception) {
            fase = "error"
            actual = null
            mensaje = textoError(e)
        } finally {
            ocupado.set(false)
        }
    }

    private fun textoError(e: Exception): String = when (e) {
        is ErrorMedicion -> e.message ?: "No se pudo medir la velocidad."
        is SocketTimeoutException -> "El servidor de pruebas tardó demasiado en responder. Intenta de nuevo."
        else -> "No se pudo conectar para medir. Revisa tu conexión a internet."
    }

    private fun abrir(ruta: String, metodo: String): HttpURLConnection {
        val c = URL(BASE + ruta).openConnection() as HttpURLConnection
        c.requestMethod = metodo
        c.connectTimeout = 10000
        c.readTimeout = 10000
        c.useCaches = false
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (descargador-android)")
        c.setRequestProperty("Accept-Encoding", "identity")
        return c
    }

    private fun transcurrido(inicio: Long): Double = (System.nanoTime() - inicio) / 1e9

    private fun redondear(x: Double): Double = Math.round(x * 10.0) / 10.0

    private fun medirPing(): Int {
        val tiempos = ArrayList<Double>()
        for (i in 0 until 8) {
            val t0 = System.nanoTime()
            val c = abrir("/__down?bytes=0", "GET")
            if (c.responseCode != 200) throw ErrorMedicion("El servidor de pruebas respondió con error ${c.responseCode}.")
            c.inputStream.use { it.readBytes() }       // leerla completa permite reutilizar la conexion
            if (i > 0) tiempos.add((System.nanoTime() - t0) / 1e6)     // la primera incluye abrir la conexion
            progreso = 2.0 + i
        }
        tiempos.sort()
        return maxOf(1, tiempos[tiempos.size / 2].roundToInt())
    }

    private fun detener(parar: AtomicBoolean, conexiones: Array<HttpURLConnection?>) {
        parar.set(true)
        for (c in conexiones) {
            try {
                c?.disconnect()
            } catch (e: Exception) {
                // ya estaba cerrada
            }
        }
    }

    private fun hiloBajada(
        i: Int, cuentas: AtomicLongArray, parar: AtomicBoolean,
        conexiones: Array<HttpURLConnection?>, errores: MutableList<Throwable>
    ) {
        try {
            val buffer = ByteArray(65536)
            while (!parar.get()) {
                val c = abrir("/__down?bytes=$TAM_BAJADA", "GET")
                conexiones[i] = c
                if (c.responseCode != 200) throw ErrorMedicion("El servidor de pruebas respondió con error ${c.responseCode}.")
                c.inputStream.use { entrada ->
                    while (!parar.get()) {
                        val n = entrada.read(buffer)
                        if (n < 0) break
                        cuentas.addAndGet(i, n.toLong())
                    }
                }
            }
        } catch (e: Exception) {
            if (!parar.get()) errores.add(e)
        }
    }

    /** Descarga en paralelo y devuelve los Mbps (sin contar el arranque lento). */
    private fun faseBajada(segundos: Double, p0: Double, p1: Double): Double {
        val cuentas = AtomicLongArray(CONEXIONES)
        val parar = AtomicBoolean(false)
        val conexiones = arrayOfNulls<HttpURLConnection>(CONEXIONES)
        val errores: MutableList<Throwable> = java.util.Collections.synchronizedList(ArrayList<Throwable>())
        fase = "bajada"
        actual = 0.0
        progreso = p0
        val inicio = System.nanoTime()
        val hilos = ArrayList<Thread>()
        for (i in 0 until CONEXIONES) {
            val h = Thread { hiloBajada(i, cuentas, parar, conexiones, errores) }
            h.isDaemon = true
            h.start()
            hilos.add(h)
        }
        val muestras = ArrayList<Pair<Double, Long>>()
        muestras.add(Pair(0.0, 0L))
        val calentamiento = minOf(1.5, segundos * 0.25)
        var base: Pair<Double, Long>? = null
        try {
            while (true) {
                Thread.sleep(250)
                val t = transcurrido(inicio)
                var total = 0L
                for (k in 0 until CONEXIONES) total += cuentas.get(k)
                muestras.add(Pair(t, total))
                if (base == null && t >= calentamiento) base = Pair(t, total)
                val ref = muestras.first { t - it.first <= 1.0 }          // ventana de 1 segundo
                if (t > ref.first) actual = redondear((total - ref.second) * 8 / (t - ref.first) / 1e6)
                progreso = p0 + (p1 - p0) * minOf(1.0, t / segundos)
                if (t >= segundos || (total == 0L && t > 5) || hilos.none { it.isAlive }) break
            }
        } finally {
            detener(parar, conexiones)
        }
        val ultimo = muestras.last()
        if (ultimo.second == 0L) throw (errores.firstOrNull() ?: ErrorMedicion("No llegaron datos desde internet."))
        val b = base
        val desde = if (b != null && ultimo.first - b.first >= 1.0) b else Pair(0.0, 0L)
        return redondear((ultimo.second - desde.second) * 8 / (ultimo.first - desde.first) / 1e6)
    }

    /**
     * Sube cuerpos cada vez mas grandes, uno tras otro, y solo cuenta lo que el servidor confirma.
     * Contar lo que sale del celular no sirve: el sistema lo guarda en memorias intermedias y en una
     * conexion lenta eso parece una velocidad enorme.
     */
    private fun hiloSubida(
        i: Int, tasas: ConcurrentHashMap<Int, Double>, parar: AtomicBoolean,
        conexiones: Array<HttpURLConnection?>, errores: MutableList<Throwable>
    ) {
        val bloque = ByteArray(65536)
        Random().nextBytes(bloque)
        var tam = 32768
        var primero = -1.0              // cuando termino la primera subida (incluye abrir la conexion: no cuenta)
        var acumulado = 0L
        try {
            while (!parar.get()) {
                val t0 = System.nanoTime() / 1e9
                val c = abrir("/__up", "POST")
                conexiones[i] = c
                c.doOutput = true
                c.setFixedLengthStreamingMode(tam)
                c.setRequestProperty("Content-Type", "application/octet-stream")
                val total = tam
                c.outputStream.use { salida ->
                    var enviado = 0
                    while (enviado < total && !parar.get()) {
                        val n = minOf(bloque.size, total - enviado)
                        salida.write(bloque, 0, n)
                        enviado += n
                    }
                }
                val codigo = c.responseCode
                if (codigo >= 400) throw ErrorMedicion("El servidor de pruebas rechazó la subida (error $codigo).")
                c.inputStream.use { it.readBytes() }
                val t1 = System.nanoTime() / 1e9
                if (parar.get()) break
                if (primero < 0) {
                    primero = t1
                } else {
                    acumulado += total
                    tasas[i] = acumulado / (t1 - primero)           // bytes por segundo de esta conexion
                }
                // la siguiente subida dura unos 0.6 s: asi pesa poco el tiempo de ida y vuelta
                tam = minOf(TAM_SUBIDA.toDouble(), tam * 4.0, maxOf(32768.0, tam * 0.6 / maxOf(t1 - t0, 0.01))).toInt()
            }
        } catch (e: Exception) {
            if (!parar.get()) errores.add(e)
        }
    }

    /** Sube en paralelo y devuelve los Mbps confirmados por el servidor. */
    private fun faseSubida(segundos: Double, p0: Double, p1: Double): Double {
        val tasas = ConcurrentHashMap<Int, Double>()
        val parar = AtomicBoolean(false)
        val conexiones = arrayOfNulls<HttpURLConnection>(CONEXIONES)
        val errores: MutableList<Throwable> = java.util.Collections.synchronizedList(ArrayList<Throwable>())
        fase = "subida"
        actual = 0.0
        progreso = p0

        fun totalMbps(): Double? {
            val lista = tasas.values.toList()
            return if (lista.isEmpty()) null else lista.sum() / lista.size * CONEXIONES * 8 / 1e6
        }

        val inicio = System.nanoTime()
        val hilos = ArrayList<Thread>()
        for (i in 0 until CONEXIONES) {
            val h = Thread { hiloSubida(i, tasas, parar, conexiones, errores) }
            h.isDaemon = true
            h.start()
            hilos.add(h)
        }
        try {
            while (true) {
                Thread.sleep(250)
                val t = transcurrido(inicio)
                val v = totalMbps()
                if (v != null) actual = redondear(v)
                progreso = p0 + (p1 - p0) * minOf(1.0, t / segundos)
                if (t >= segundos || (v == null && t > 5 && errores.isEmpty()) || hilos.none { it.isAlive }) break
            }
        } finally {
            detener(parar, conexiones)
        }
        val v = totalMbps() ?: throw (errores.firstOrNull() ?: ErrorMedicion("El servidor de pruebas no confirmó la subida."))
        return redondear(v)
    }
}
