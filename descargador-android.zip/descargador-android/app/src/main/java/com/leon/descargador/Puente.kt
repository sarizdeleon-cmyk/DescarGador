package com.leon.descargador

import android.webkit.JavascriptInterface
import org.json.JSONObject

/**
 * Lo que la pagina (index.html) puede pedirle a la app. Sustituye al servidor local de la
 * version de computadora: la pagina llama a window.AndroidApi.llamar("/api/estado", ...).
 */
class Puente(private val actividad: MainActivity) {

    @JavascriptInterface
    fun llamar(ruta: String, cuerpo: String): String {
        return try {
            Motor.api(ruta, cuerpo, actividad).toString()
        } catch (e: Exception) {
            val o = JSONObject()
            o.put("ok", false)
            o.put("error", e.message ?: "error")
            o.toString()
        }
    }

    @JavascriptInterface
    fun pegar(): String = actividad.textoDelPortapapeles()

    @JavascriptInterface
    fun tema(): String = actividad.tema()

    @JavascriptInterface
    fun acento(): String = actividad.acento()
}
