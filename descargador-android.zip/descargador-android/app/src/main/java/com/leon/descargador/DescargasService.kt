package com.leon.descargador

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager

/**
 * Servicio en primer plano: mantiene viva la app mientras hay descargas, aunque cambies de app
 * o se apague la pantalla. Se enciende al pedir una descarga y se apaga solo al terminar todas.
 */
class DescargasService : Service() {
    private var cerrojo: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CANAL, "Descargas", NotificationManager.IMPORTANCE_LOW))
        val abrir = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notificacion = Notification.Builder(this, CANAL)
            .setContentTitle("Descargador de videos")
            .setContentText("Descargando…")
            .setSmallIcon(R.drawable.ic_notificacion)
            .setContentIntent(abrir)
            .setOngoing(true)
            .build()
        startForeground(1, notificacion, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (cerrojo == null) {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            val c = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "descargador:descargas")
            c.acquire(2L * 60L * 60L * 1000L)
            cerrojo = c
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        val c = cerrojo
        if (c != null && c.isHeld) c.release()
        cerrojo = null
        super.onDestroy()
    }

    companion object {
        private const val CANAL = "descargas"

        fun arrancar(contexto: Context) {
            try {
                contexto.startForegroundService(Intent(contexto, DescargasService::class.java))
            } catch (e: Exception) {
                // sin servicio la descarga sigue mientras la app este abierta
            }
        }

        fun detener(contexto: Context) {
            try {
                contexto.stopService(Intent(contexto, DescargasService::class.java))
            } catch (e: Exception) {
                // ya estaba detenido
            }
        }
    }
}
