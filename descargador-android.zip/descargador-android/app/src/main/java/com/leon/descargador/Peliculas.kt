package com.leon.descargador

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder

/**
 * Busca peliculas libres (dominio publico) en la coleccion "feature_films" de Internet Archive.
 * Solo busca: la descarga la hace el mismo motor de siempre (yt-dlp entiende los links
 * https://archive.org/details/<id>).
 *
 * La busqueda corre en segundo plano y la interfaz pregunta por el resultado, igual que el medidor
 * de velocidad: asi la pagina nunca se queda congelada esperando a la red.
 */
object Peliculas {
    private const val BASE = "https://archive.org"
    private const val POR_PAGINA = 20
    private const val MAX_BYTES = 3 * 1024 * 1024
    private val RE_ID = Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,150}$")
    private val RE_ANIO = Regex("""\b(1[89]\d\d|20\d\d)\b""")
    private val OPERADORES = setOf("and", "or", "not", "to")

    class Resultado(val id: String, val titulo: String, val anio: String, val descargas: Long, val idioma: String) {
        fun json(): JSONObject {
            val o = JSONObject()
            o.put("id", id)
            o.put("titulo", titulo)
            o.put("anio", anio)
            o.put("descargas", descargas)
            o.put("idioma", idioma)
            o.put("url", "$BASE/details/$id")
            o.put("imagen", "$BASE/services/img/$id")
            return o
        }
    }

    private val candado = Any()
    private var token = 0
    private var estado = "inactiva"          // inactiva | buscando | lista | error
    private var mensaje = ""
    private var total = 0
    private var pagina = 1
    private var resultados: List<Resultado> = emptyList()

    /** Empieza una busqueda y devuelve su numero (la interfaz lo usa para ignorar busquedas viejas). */
    fun buscar(texto: String, espanol: Boolean, paginaPedida: Int): Int {
        val pag = paginaPedida.coerceIn(1, 200)
        val mio = synchronized(candado) {
            token += 1
            estado = "buscando"
            mensaje = ""
            pagina = pag
            resultados = emptyList()
            total = 0
            token
        }
        Thread { trabajar(mio, texto, espanol, pag) }.start()
        return mio
    }

    fun json(): JSONObject {
        val o = JSONObject()
        synchronized(candado) {
            o.put("token", token)
            o.put("estado", estado)
            o.put("mensaje", mensaje)
            o.put("pagina", pagina)
            o.put("total", total)
            val arr = JSONArray()
            for (r in resultados) arr.put(r.json())
            o.put("resultados", arr)
        }
        return o
    }

    private fun trabajar(mio: Int, texto: String, espanol: Boolean, pag: Int) {
        var nuevoEstado = "lista"
        var nuevoMensaje = ""
        var nuevoTotal = 0
        var lista: List<Resultado> = emptyList()
        try {
            val cuerpo = pedir(urlDeBusqueda(texto, espanol, pag))
            val respuesta = JSONObject(cuerpo).getJSONObject("response")
            nuevoTotal = respuesta.optInt("numFound", 0)
            lista = leerDocs(respuesta.optJSONArray("docs"))
        } catch (e: SocketTimeoutException) {
            nuevoEstado = "error"
            nuevoMensaje = "Internet Archive tardó demasiado en responder. Intenta de nuevo."
        } catch (e: IOException) {
            nuevoEstado = "error"
            nuevoMensaje = e.message?.takeIf { it.startsWith("Internet Archive") }
                ?: "No se pudo conectar. Revisa tu conexión a internet."
        } catch (e: Exception) {
            nuevoEstado = "error"
            nuevoMensaje = "Internet Archive respondió algo inesperado. Intenta de nuevo."
        }
        synchronized(candado) {
            if (mio != token) return          // ya hay una busqueda mas nueva: esta se descarta
            estado = nuevoEstado
            mensaje = nuevoMensaje
            total = nuevoTotal
            resultados = lista
        }
    }

    /** Arma la consulta: titulo (o director/estudio) + solo peliculas de la coleccion libre + idioma opcional. */
    fun consulta(texto: String, espanol: Boolean): String {
        val limpio = texto.lowercase()
            .replace(Regex("""[^\p{L}\p{N}\s]"""), " ")
            .trim()
            .replace(Regex("""\s+"""), " ")
        val partes = ArrayList<String>()
        // "and", "or" y "not" escritos por la persona podrian leerse como operadores de la busqueda: se omiten
        val terminos = limpio.split(" ").filter { it.isNotEmpty() && it !in OPERADORES }.take(8)
        if (terminos.isNotEmpty()) {
            val palabras = terminos.joinToString(" AND ")
            partes.add("(title:($palabras) OR creator:($palabras))")
        }
        partes.add("collection:(feature_films)")
        partes.add("mediatype:(movies)")
        if (espanol) partes.add("language:(spanish OR spa OR es)")
        return partes.joinToString(" AND ")
    }

    fun urlDeBusqueda(texto: String, espanol: Boolean, pag: Int): String {
        fun cod(s: String) = URLEncoder.encode(s, "UTF-8")
        val campos = listOf("identifier", "title", "year", "downloads", "language")
            .joinToString("&") { "fl%5B%5D=$it" }
        return BASE + "/advancedsearch.php?q=" + cod(consulta(texto, espanol)) + "&" + campos +
            "&sort%5B%5D=" + cod("downloads desc") + "&rows=" + POR_PAGINA + "&page=" + pag + "&output=json"
    }

    private fun pedir(direccion: String): String {
        val c = URL(direccion).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"
            c.connectTimeout = 12000
            c.readTimeout = 15000
            c.useCaches = false
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (descargador-android)")
            c.setRequestProperty("Accept", "application/json")
            val codigo = c.responseCode
            if (codigo != 200) throw IOException("Internet Archive respondió con error $codigo. Intenta más tarde.")
            val salida = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            c.inputStream.use { entrada ->
                while (true) {
                    val n = entrada.read(buffer)
                    if (n < 0) break
                    salida.write(buffer, 0, n)
                    if (salida.size() > MAX_BYTES) throw IOException("La respuesta de Internet Archive es demasiado grande.")
                }
            }
            return salida.toString("UTF-8")
        } finally {
            c.disconnect()
        }
    }

    // El archivo a veces manda un dato suelto y a veces una lista de datos: se toma el primero.
    private fun texto(o: JSONObject, clave: String): String {
        val v = o.opt(clave)
        return when {
            v == null || v == JSONObject.NULL -> ""
            v is JSONArray -> if (v.length() > 0) v.optString(0) else ""
            else -> v.toString()
        }.trim()
    }

    fun leerDocs(docs: JSONArray?): List<Resultado> {
        val salida = ArrayList<Resultado>()
        if (docs == null) return salida
        for (i in 0 until docs.length()) {
            val d = docs.optJSONObject(i) ?: continue
            val id = texto(d, "identifier")
            if (!RE_ID.matches(id)) continue
            val titulo = texto(d, "title").ifEmpty { id }.take(160)
            val anio = RE_ANIO.find(texto(d, "year"))?.value ?: ""
            val descargas = texto(d, "downloads").toDoubleOrNull()?.toLong() ?: 0L
            salida.add(Resultado(id, titulo, anio, descargas, texto(d, "language").take(30)))
        }
        return salida
    }
}
