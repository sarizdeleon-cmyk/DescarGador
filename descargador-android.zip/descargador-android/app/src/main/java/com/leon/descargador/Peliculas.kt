package com.leon.descargador

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar

/**
 * Busca peliculas libres (dominio publico) en la coleccion "feature_films" de Internet Archive.
 * Solo busca: la descarga la hace el mismo motor de siempre (yt-dlp entiende los links
 * https://archive.org/details/<id>).
 *
 * La busqueda corre en segundo plano y la interfaz pregunta por el resultado, igual que el medidor
 * de velocidad: asi la pagina nunca se queda congelada esperando a la red.
 */
object Peliculas {
    private const val BASE = "https://archive.org"
    private const val POR_PAGINA = 20
    private const val MAX_BYTES = 6 * 1024 * 1024
    private const val MAX_SINOPSIS = 700
    private const val ANIO_MIN = 1850
    private const val ANIO_MAX = 2100
    private val RE_ID = Regex("^[A-Za-z0-9][A-Za-z0-9._-]{0,150}$")
    private val RE_ANIO = Regex("""\b(1[89]\d\d|20\d\d)\b""")
    private val RE_ESPACIOS = Regex("""\s+""")
    private val RE_SALTOS = Regex("""(?i)<br\s*/?>|</p>|</div>|</li>""")
    private val RE_ETIQUETA = Regex("<[^>]*>")
    private val RE_ENTIDAD = Regex("&(#[xX][0-9a-fA-F]{1,4}|#\\d{1,5}|[A-Za-z][A-Za-z0-9]{1,9});")
    private val ENTIDADES = mapOf(
        "amp" to "&", "lt" to "<", "gt" to ">", "quot" to "\"", "apos" to "'", "nbsp" to " ",
        "aacute" to "á", "eacute" to "é", "iacute" to "í", "oacute" to "ó", "uacute" to "ú", "ntilde" to "ñ",
        "Aacute" to "Á", "Eacute" to "É", "Iacute" to "Í", "Oacute" to "Ó", "Uacute" to "Ú", "Ntilde" to "Ñ",
        "agrave" to "à", "egrave" to "è", "igrave" to "ì", "ograve" to "ò", "ugrave" to "ù",
        "acirc" to "â", "ecirc" to "ê", "icirc" to "î", "ocirc" to "ô", "ucirc" to "û",
        "auml" to "ä", "euml" to "ë", "iuml" to "ï", "ouml" to "ö", "uuml" to "ü", "Uuml" to "Ü", "Ouml" to "Ö", "Auml" to "Ä",
        "ccedil" to "ç", "Ccedil" to "Ç", "szlig" to "ß", "iexcl" to "¡", "iquest" to "¿",
        "laquo" to "«", "raquo" to "»", "ndash" to "–", "mdash" to "—", "hellip" to "…",
        "lsquo" to "‘", "rsquo" to "’", "ldquo" to "“", "rdquo" to "”", "copy" to "©", "deg" to "°"
    )
    private val RE_PALABRAS = Regex("""[^\p{L}\p{N}]+""")
    private val OPERADORES = setOf("and", "or", "not", "to")

    /**
     * Generos que ofrece la interfaz. "consulta" son las palabras que se buscan en los temas (subject) del
     * archivo, que son texto libre en ingles o espanol; "claves" sirven para reconocer el genero de cada resultado.
     */
    private class Genero(val nombre: String, val consulta: List<String>, val claves: List<String>)

    private val GENEROS = listOf(
        Genero("Comedia", listOf("comedy", "comedia"), listOf("comedy", "comedia", "comedie")),
        Genero("Drama", listOf("drama"), listOf("drama")),
        Genero("Terror", listOf("horror", "terror"), listOf("horror", "terror", "horreur")),
        Genero("Ciencia ficción", listOf("\"science fiction\"", "sci-fi", "scifi", "\"ciencia ficcion\""),
            listOf("science fiction", "sci-fi", "scifi", "sci fi", "ciencia ficcion", "ciencia ficción")),
        Genero("Acción y aventura", listOf("action", "adventure", "accion", "aventura", "aventuras"),
            listOf("action", "adventure", "accion", "acción", "aventura")),
        Genero("Western", listOf("western"), listOf("western")),
        Genero("Romance", listOf("romance", "romantic", "romantica"), listOf("romance", "romantic", "romantica", "romántica")),
        Genero("Misterio y crimen", listOf("mystery", "crime", "thriller", "\"film noir\"", "misterio", "detective"),
            listOf("mystery", "crime", "thriller", "film noir", "noir", "misterio", "detective")),
        Genero("Animación", listOf("animation", "animated", "cartoon", "animacion"), listOf("animat", "cartoon", "animacion", "animación")),
        Genero("Infantil y familiar", listOf("children", "family", "kids", "infantil", "familiar"),
            listOf("children", "family", "kids", "infantil", "familiar")),
        Genero("Musical", listOf("musical"), listOf("musical")),
        Genero("Guerra", listOf("war", "guerra"), listOf("war", "guerra")),
        Genero("Documental", listOf("documentary", "documental"), listOf("documentar", "documental")),
        Genero("Cine mudo", listOf("silent", "mudo"), listOf("silent", "mudo"))
    )

    fun nombresDeGeneros(): List<String> = GENEROS.map { it.nombre }

    class Resultado(
        val id: String, val titulo: String, val anio: String, val descargas: Long,
        val idioma: String, val sinopsis: String, val generos: List<String>
    ) {
        fun json(): JSONObject {
            val o = JSONObject()
            o.put("id", id)
            o.put("titulo", titulo)
            o.put("anio", anio)
            o.put("descargas", descargas)
            o.put("idioma", idioma)
            o.put("sinopsis", sinopsis)
            o.put("generos", JSONArray(generos))
            o.put("url", "$BASE/details/$id")
            o.put("imagen", "$BASE/services/img/$id")
            return o
        }
    }

    private val candado = Any()
    private var token = 0
    private var estado = "inactiva"          // inactiva | buscando | lista | error
    private var mensaje = ""
    private var total = 0
    private var pagina = 1
    private var resultados: List<Resultado> = emptyList()

    /** Empieza una busqueda y devuelve su numero (la interfaz lo usa para ignorar busquedas viejas). anio 0 = cualquiera. */
    fun buscar(texto: String, espanol: Boolean, genero: String, anio: Int, paginaPedida: Int): Int {
        val pag = paginaPedida.coerceIn(1, 200)
        val an = if (anio in ANIO_MIN..ANIO_MAX) anio else 0
        val mio = synchronized(candado) {
            token += 1
            estado = "buscando"
            mensaje = ""
            pagina = pag
            resultados = emptyList()
            total = 0
            token
        }
        Thread { trabajar(mio, texto, espanol, genero, an, pag) }.start()
        return mio
    }

    // ---- Años disponibles: el mas reciente y el mas viejo que de verdad tienen peliculas ----
    private var aniosEstado = "inactiva"      // inactiva | buscando | lista | error
    private var aniosMax = 0
    private var aniosMin = 0

    /** Averigua (una sola vez con exito) el año mas nuevo y el mas viejo de la coleccion. Devuelve false si ya estaba en marcha o resuelto. */
    fun iniciarAnios(): Boolean {
        synchronized(candado) {
            if (aniosEstado == "buscando" || aniosEstado == "lista") return false
            aniosEstado = "buscando"
        }
        Thread { sondearAnios() }.start()
        return true
    }

    fun aniosJson(): JSONObject {
        val o = JSONObject()
        synchronized(candado) {
            o.put("estado", aniosEstado)
            o.put("max", aniosMax)
            o.put("min", aniosMin)
        }
        return o
    }

    private fun sondearAnios() {
        var nuevoEstado = "lista"
        var max = 0
        var min = 0
        try {
            val hasta = Calendar.getInstance().get(Calendar.YEAR)
            max = anioExtremo(hasta, "desc")
            min = anioExtremo(hasta, "asc")
            // si algo vino raro (por ejemplo el orden no se aplico y max y min salen casi iguales), la interfaz usa su lista de respaldo
            if (max < ANIO_MIN || min < ANIO_MIN || max > hasta || max - min < 10) nuevoEstado = "error"
        } catch (e: Exception) {
            nuevoEstado = "error"
        }
        synchronized(candado) {
            aniosEstado = nuevoEstado
            aniosMax = if (nuevoEstado == "lista") max else 0
            aniosMin = if (nuevoEstado == "lista") min else 0
        }
    }

    private fun anioExtremo(hasta: Int, orden: String): Int {
        val cuerpo = pedir(urlDeAnios(hasta, orden))
        val docs = JSONObject(cuerpo).getJSONObject("response").optJSONArray("docs") ?: return 0
        val d = docs.optJSONObject(0) ?: return 0
        return RE_ANIO.find(texto(d, "year"))?.value?.toIntOrNull() ?: 0
    }

    /** Pregunta por la pelicula mas nueva (desc) o mas vieja (asc), sin pasarse del año actual para ignorar fechas absurdas. */
    fun urlDeAnios(hasta: Int, orden: String): String {
        fun cod(s: String) = URLEncoder.encode(s, "UTF-8")
        val q = "collection:(feature_films) AND mediatype:(movies) AND year:[$ANIO_MIN TO $hasta]"
        return BASE + "/advancedsearch.php?q=" + cod(q) + "&fl%5B%5D=identifier&fl%5B%5D=year" +
            "&sort%5B%5D=" + cod("year $orden") + "&rows=1&page=1&output=json"
    }

    fun json(): JSONObject {
        val o = JSONObject()
        synchronized(candado) {
            o.put("token", token)
            o.put("estado", estado)
            o.put("mensaje", mensaje)
            o.put("pagina", pagina)
            o.put("total", total)
            val arr = JSONArray()
            for (r in resultados) arr.put(r.json())
            o.put("resultados", arr)
        }
        return o
    }

    private fun trabajar(mio: Int, texto: String, espanol: Boolean, genero: String, anio: Int, pag: Int) {
        var nuevoEstado = "lista"
        var nuevoMensaje = ""
        var nuevoTotal = 0
        var lista: List<Resultado> = emptyList()
        try {
            val cuerpo = pedir(urlDeBusqueda(texto, espanol, genero, anio, pag))
            val respuesta = JSONObject(cuerpo).getJSONObject("response")
            nuevoTotal = respuesta.optInt("numFound", 0)
            lista = leerDocs(respuesta.optJSONArray("docs"))
        } catch (e: SocketTimeoutException) {
            nuevoEstado = "error"
            nuevoMensaje = "Internet Archive tardó demasiado en responder. Intenta de nuevo."
        } catch (e: IOException) {
            nuevoEstado = "error"
            nuevoMensaje = e.message?.takeIf { it.startsWith("Internet Archive") }
                ?: "No se pudo conectar. Revisa tu conexión a internet."
        } catch (e: Exception) {
            nuevoEstado = "error"
            nuevoMensaje = "Internet Archive respondió algo inesperado. Intenta de nuevo."
        }
        synchronized(candado) {
            if (mio != token) return          // ya hay una busqueda mas nueva: esta se descarta
            estado = nuevoEstado
            mensaje = nuevoMensaje
            total = nuevoTotal
            resultados = lista
        }
    }

    /** Arma la consulta: titulo (o director/estudio) + solo peliculas de la coleccion libre + idioma, genero y año opcionales. */
    fun consulta(texto: String, espanol: Boolean, genero: String = "", anio: Int = 0): String {
        val limpio = texto.lowercase()
            .replace(Regex("""[^\p{L}\p{N}\s]"""), " ")
            .trim()
            .replace(RE_ESPACIOS, " ")
        val partes = ArrayList<String>()
        // "and", "or" y "not" escritos por la persona podrian leerse como operadores de la busqueda: se omiten
        val terminos = limpio.split(" ").filter { it.isNotEmpty() && it !in OPERADORES }.take(8)
        if (terminos.isNotEmpty()) {
            val palabras = terminos.joinToString(" AND ")
            partes.add("(title:($palabras) OR creator:($palabras))")
        }
        partes.add("collection:(feature_films)")
        partes.add("mediatype:(movies)")
        if (espanol) partes.add("language:(spanish OR spa OR es)")
        val g = GENEROS.firstOrNull { it.nombre == genero }
        if (g != null) partes.add("subject:(" + g.consulta.joinToString(" OR ") + ")")
        if (anio in ANIO_MIN..ANIO_MAX) partes.add("year:($anio)")
        return partes.joinToString(" AND ")
    }

    fun urlDeBusqueda(texto: String, espanol: Boolean, genero: String, anio: Int, pag: Int): String {
        fun cod(s: String) = URLEncoder.encode(s, "UTF-8")
        val campos = listOf("identifier", "title", "year", "downloads", "language", "description", "subject")
            .joinToString("&") { "fl%5B%5D=$it" }
        return BASE + "/advancedsearch.php?q=" + cod(consulta(texto, espanol, genero, anio)) + "&" + campos +
            "&sort%5B%5D=" + cod("downloads desc") + "&rows=" + POR_PAGINA + "&page=" + pag + "&output=json"
    }

    private fun pedir(direccion: String): String {
        val c = URL(direccion).openConnection() as HttpURLConnection
        try {
            c.requestMethod = "GET"
            c.connectTimeout = 12000
            c.readTimeout = 15000
            c.useCaches = false
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (descargador-android)")
            c.setRequestProperty("Accept", "application/json")
            val codigo = c.responseCode
            if (codigo != 200) throw IOException("Internet Archive respondió con error $codigo. Intenta más tarde.")
            val salida = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(16 * 1024)
            c.inputStream.use { entrada ->
                while (true) {
                    val n = entrada.read(buffer)
                    if (n < 0) break
                    salida.write(buffer, 0, n)
                    if (salida.size() > MAX_BYTES) throw IOException("La respuesta de Internet Archive es demasiado grande.")
                }
            }
            return salida.toString("UTF-8")
        } finally {
            c.disconnect()
        }
    }

    // El archivo a veces manda un dato suelto y a veces una lista de datos.
    private fun valores(o: JSONObject, clave: String): List<String> {
        val v = o.opt(clave)
        return when {
            v == null || v == JSONObject.NULL -> emptyList()
            v is JSONArray -> (0 until v.length()).mapNotNull { i ->
                val e = v.opt(i)
                if (e == null || e == JSONObject.NULL) null else e.toString()     // un null dentro de la lista no debe salir como la palabra "null"
            }
            else -> listOf(v.toString())
        }.map { it.trim() }.filter { it.isNotEmpty() }
    }

    private fun texto(o: JSONObject, clave: String): String = valores(o, clave).firstOrNull() ?: ""

    /** Quita etiquetas HTML y entidades (&amp;, &aacute;, &#39;...) de la sinopsis y la recorta. */
    fun limpiarTexto(original: String, max: Int): String {
        var s = RE_SALTOS.replace(original, " ")
        s = RE_ETIQUETA.replace(s, " ")
        // una sola pasada: "&amp;lt;" queda como "&lt;" y no se decodifica dos veces
        s = RE_ENTIDAD.replace(s) { m ->
            val k = m.groupValues[1]
            val codigo = when {
                k.startsWith("#x") || k.startsWith("#X") -> k.substring(2).toIntOrNull(16)
                k.startsWith("#") -> k.substring(1).toIntOrNull()
                else -> null
            }
            when {
                k.startsWith("#") -> if (codigo != null && codigo in 32..0xFFFF && codigo !in 0xD800..0xDFFF) codigo.toChar().toString() else " "
                else -> ENTIDADES[k] ?: m.value
            }
        }
        s = RE_ESPACIOS.replace(s, " ").trim()
        return if (s.length > max) s.substring(0, max).trimEnd() + "…" else s
    }

    /** "spa" o "Spanish" -> "Español", etc. Lo que no se reconoce se muestra tal cual. */
    fun nombreDeIdioma(crudo: String): String {
        val primero = crudo.split(';', ',', '/').firstOrNull()?.trim() ?: ""
        val x = primero.lowercase()
        val nombre = when (x) {
            "spa", "es", "spanish", "español", "espanol", "castellano", "spanish; castilian" -> "Español"
            "eng", "en", "english", "inglés", "ingles" -> "Inglés"
            "fre", "fra", "fr", "french", "francés", "frances" -> "Francés"
            "ger", "deu", "de", "german", "alemán", "aleman" -> "Alemán"
            "ita", "it", "italian", "italiano" -> "Italiano"
            "por", "pt", "portuguese", "portugués", "portugues" -> "Portugués"
            "rus", "ru", "russian", "ruso" -> "Ruso"
            "jpn", "ja", "japanese", "japonés", "japones" -> "Japonés"
            "chi", "zho", "zh", "chinese", "chino" -> "Chino"
            "swe", "sv", "swedish", "sueco" -> "Sueco"
            "dut", "nld", "nl", "dutch", "holandés", "holandes" -> "Holandés"
            else -> ""
        }
        return nombre.ifEmpty { primero.take(20) }
    }

    private fun cumple(clave: String, palabras: List<String>, textoCompleto: String): Boolean =
        if (clave.contains(' ') || clave.contains('-')) textoCompleto.contains(clave)
        else palabras.any { it == clave || (clave.length >= 5 && it.startsWith(clave)) }

    /** Generos de una pelicula segun sus temas (hasta 3). */
    fun generosDe(temas: List<String>): List<String> {
        if (temas.isEmpty()) return emptyList()
        val completo = temas.joinToString(" ; ").lowercase()
        val palabras = RE_PALABRAS.split(completo).filter { it.isNotEmpty() }
        return GENEROS.filter { g -> g.claves.any { cumple(it, palabras, completo) } }.map { it.nombre }.take(3)
    }

    fun leerDocs(docs: JSONArray?): List<Resultado> {
        val salida = ArrayList<Resultado>()
        if (docs == null) return salida
        for (i in 0 until docs.length()) {
            val d = docs.optJSONObject(i) ?: continue
            val id = texto(d, "identifier")
            if (!RE_ID.matches(id)) continue
            val titulo = texto(d, "title").ifEmpty { id }.take(160)
            val anio = RE_ANIO.find(texto(d, "year"))?.value ?: ""
            val descargas = texto(d, "downloads").toDoubleOrNull()?.toLong() ?: 0L
            val sinopsis = limpiarTexto(valores(d, "description").joinToString(" "), MAX_SINOPSIS)
            val temas = valores(d, "subject").flatMap { it.split(';', ',') }.map { it.trim() }.filter { it.isNotEmpty() }
            salida.add(Resultado(id, titulo, anio, descargas, nombreDeIdioma(texto(d, "language")), sinopsis, generosDe(temas)))
        }
        return salida
    }
}
