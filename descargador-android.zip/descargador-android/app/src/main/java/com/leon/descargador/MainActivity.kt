package com.leon.descargador

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.DownloadManager
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** Una sola pantalla: la misma interfaz web (assets/index.html) dentro de un WebView. */
class MainActivity : Activity() {
    private lateinit var web: WebView

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Motor.iniciar(applicationContext)
        pedirPermisoDeNotificaciones()

        web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.mediaPlaybackRequiresUserGesture = false      // la pelicula arranca sola despues de tocar "Ver ahora"
        web.setBackgroundColor(if (oscuro()) 0xFF141218.toInt() else 0xFFF7F2FA.toInt())
        web.addJavascriptInterface(Puente(this), "AndroidApi")
        web.webViewClient = object : WebViewClient() {
            // Los links (por ejemplo el de WhatsApp) se abren fuera de la app
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val esquema = request.url.scheme
                if (esquema == "http" || esquema == "https") {
                    try {
                        startActivity(Intent(Intent.ACTION_VIEW, request.url))
                    } catch (e: Exception) {
                        // no hay navegador
                    }
                    return true
                }
                return false
            }
        }
        setContentView(web)
        web.loadUrl("file:///android_asset/index.html")
    }

    // Con el reproductor abierto, "atras" lo cierra en vez de salir de la app
    @Suppress("OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        web.evaluateJavascript("(window.cerrarReproductor ? window.cerrarReproductor() : false)") { resultado ->
            if (resultado != "true") atrasNormal()
        }
    }

    @Suppress("DEPRECATION")
    private fun atrasNormal() {
        super.onBackPressed()
    }

    // Si la app pasa a segundo plano, la pelicula se pausa
    override fun onPause() {
        if (::web.isInitialized) {
            web.evaluateJavascript("(function(){var v=document.getElementById('rep-video'); if(v){v.pause();}})()", null)
        }
        super.onPause()
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("AndroidApi")
        web.destroy()
        super.onDestroy()
    }

    private fun pedirPermisoDeNotificaciones() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    // ---- lo que usa el puente con la pagina ----

    fun abrirDescargas() {
        runOnUiThread {
            try {
                startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
            } catch (e: Exception) {
                // el telefono no tiene visor de descargas
            }
        }
    }

    fun cerrar() {
        runOnUiThread { finish() }
    }

    /** Reproductor abierto: pantalla completa (sin barras del sistema) y pantalla siempre encendida. */
    @Suppress("DEPRECATION")
    fun reproductor(abierto: Boolean) {
        runOnUiThread {
            if (abierto) {
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            } else {
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_VISIBLE
            }
        }
    }

    fun textoDelPortapapeles(): String {
        val resultado = arrayOf("")
        val espera = CountDownLatch(1)
        runOnUiThread {
            try {
                val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                val clip = cm.primaryClip
                if (clip != null && clip.itemCount > 0) {
                    resultado[0] = clip.getItemAt(0).coerceToText(this).toString()
                }
            } catch (e: Exception) {
                // sin permiso o vacio
            }
            espera.countDown()
        }
        espera.await(2, TimeUnit.SECONDS)
        return resultado[0]
    }

    private fun oscuro(): Boolean =
        (resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

    fun tema(): String = if (oscuro()) "dark" else "light"

    /** Color de acento del sistema (Material You en Android 12 o mas) y color de texto legible encima. */
    fun acento(): String {
        val oscuro = oscuro()
        val color = if (Build.VERSION.SDK_INT >= 31) {
            getColor(if (oscuro) android.R.color.system_accent1_200 else android.R.color.system_accent1_600)
        } else {
            if (oscuro) 0xFFD0BCFF.toInt() else 0xFF6750A4.toInt()
        }
        val r = (color shr 16) and 0xFF
        val g = (color shr 8) and 0xFF
        val b = color and 0xFF
        val luminancia = (0.299 * r + 0.587 * g + 0.114 * b) / 255.0
        val texto = if (luminancia > 0.6) "#000000" else "#FFFFFF"
        return String.format("#%02X%02X%02X|%s", r, g, b, texto)
    }
}
