package com.leon.descargador

import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.text.Normalizer

/**
 * Busca en YouTube peliculas completas en español (Dailymotion tiene su propio archivo, Dailymotion.kt, con las mismas reglas): videos "normales" cuyo titulo dice "completa" y que duran mas de
 * 60 minutos. La busqueda la hace yt-dlp (el mismo que descarga), sin cuenta ni clave de YouTube.
 *
 * Igual que Peliculas: corre en segundo plano y la interfaz pregunta por el resultado, para que la pagina nunca se
 * quede congelada esperando a la red. La descarga y el "Ver ahora" usan el motor de siempre.
 */
object Youtube {
    private const val POR_LOTE = 40              // resultados que se piden a YouTube cada vez
    private const val MAX_LOTES = 3              // cuantos lotes se revisan en una sola busqueda
    private const val QUIERO_AL_MENOS = 12       // si salen menos, se sigue revisando (hasta MAX_LOTES)
    private const val MIN_SEGUNDOS = 3600.0      // "mayor a 60 minutos"
    private const val FILTRO = "EgQQARgC"        // filtro de YouTube: solo videos, de mas de 20 minutos
    private const val BASE = "película completa en español"
    private const val MAX_TITULO = 160
    private val RE_ID = Regex("^[A-Za-z0-9_-]{11}$")
    private val RE_ESPACIOS = Regex("""\s+""")
    private val RE_RARO = Regex("""[^\p{L}\p{N} ]""")
    private val RE_ACENTOS = Regex("""\p{M}+""")

    /** Un resultado de busqueda. fuente: "yt" (YouTube) o "dm" (Dailymotion). */
    class Video(val fuente: String, val id: String, val titulo: String, val canal: String, val segundos: Long, val vistas: Long, val miniatura: String = "") {
        fun json(): JSONObject {
            val o = JSONObject()
            o.put("fuente", fuente)
            o.put("id", id)
            o.put("titulo", titulo)
            o.put("canal", canal)
            o.put("segundos", segundos)
            o.put("vistas", vistas)
            o.put("url", Directo.urlDe(fuente, id) ?: "")
            o.put("imagen", when {
                miniatura.startsWith("https://") -> miniatura
                fuente == "dm" -> "https://www.dailymotion.com/thumbnail/video/$id"
                else -> "https://i.ytimg.com/vi/$id/mqdefault.jpg"
            })
            return o
        }
    }

    private val candado = Any()
    private var token = 0
    private var estado = "inactiva"          // inactiva | buscando | lista | error
    private var mensaje = ""
    private var siguiente = 0                // cuantos resultados de YouTube ya se revisaron (donde sigue "Ver más")
    private var hayMas = false
    private var resultados: List<Video> = emptyList()

    /** Empieza una busqueda (desde = 0) o pide la siguiente tanda (desde = "siguiente" de la respuesta anterior). */
    fun buscar(texto: String, desde: Int): Int {
        val d = desde.coerceIn(0, 1000)
        val mio = synchronized(candado) {
            token += 1
            estado = "buscando"
            mensaje = ""
            resultados = emptyList()
            hayMas = false
            siguiente = d
            token
        }
        Thread { trabajar(mio, texto, d) }.start()
        return mio
    }

    fun json(): JSONObject {
        val o = JSONObject()
        synchronized(candado) {
            o.put("token", token)
            o.put("estado", estado)
            o.put("mensaje", mensaje)
            o.put("siguiente", siguiente)
            o.put("hay_mas", hayMas)
            val arr = JSONArray()
            for (v in resultados) arr.put(v.json())
            o.put("resultados", arr)
        }
        return o
    }

    private fun trabajar(mio: Int, texto: String, desde: Int) {
        var nuevoEstado = "lista"
        var nuevoMensaje = ""
        var lista: List<Video> = emptyList()
        var actual = desde
        var quedan = false
        try {
            if (!Motor.esperarListo(90000)) throw IllegalStateException("preparando")
            val url = urlDeBusqueda(texto)
            val vistos = HashSet<String>()
            val acumulado = ArrayList<Video>()
            var lotes = 0
            quedan = true
            while (lotes < MAX_LOTES && acumulado.size < QUIERO_AL_MENOS && quedan) {
                val salida = ejecutar(url, actual + 1, actual + POR_LOTE)
                val entradas = JSONObject(extraerJson(salida)).optJSONArray("entries")
                val n = entradas?.length() ?: 0
                acumulado.addAll(filtrar(entradas, vistos))
                actual += n
                quedan = n >= POR_LOTE          // si YouTube devolvio menos de lo pedido, ya no hay mas
                lotes += 1
            }
            lista = acumulado
        } catch (e: IllegalStateException) {
            nuevoEstado = "error"
            nuevoMensaje = "La app todavía se está preparando (solo tarda la primera vez). Intenta de nuevo en unos segundos."
        } catch (e: Exception) {
            nuevoEstado = "error"
            nuevoMensaje = "No se pudo buscar en YouTube. Revisa tu conexión e intenta de nuevo."
        }
        synchronized(candado) {
            if (mio != token) return          // ya hay una busqueda mas nueva: esta se descarta
            estado = nuevoEstado
            mensaje = nuevoMensaje
            resultados = lista
            siguiente = actual
            hayMas = nuevoEstado == "lista" && quedan
        }
    }

    private fun ejecutar(url: String, desde: Int, hasta: Int): String {
        val req = YoutubeDLRequest(url)
        req.addOption("--flat-playlist")
        req.addOption("--dump-single-json")
        req.addOption("--no-warnings")
        req.addOption("--no-colors")
        req.addOption("--socket-timeout", "20")
        req.addOption("--playlist-start", desde.toString())
        req.addOption("--playlist-end", hasta.toString())
        return YoutubeDL.getInstance().execute(req, "yt-busqueda-" + System.nanoTime()) { _, _, _ -> }.out
    }

    /** yt-dlp a veces agrega avisos antes o despues del JSON: se toma desde la primera llave hasta la ultima. */
    fun extraerJson(salida: String): String {
        val a = salida.indexOf('{')
        val b = salida.lastIndexOf('}')
        if (a < 0 || b < a) throw IllegalArgumentException("sin datos")
        return salida.substring(a, b + 1)
    }

    /** Lo que la persona escribio (opcional) + "película completa en español". Sin comillas ni simbolos raros. */
    fun consulta(texto: String): String {
        val limpio = RE_ESPACIOS.replace(RE_RARO.replace(texto, " "), " ").trim().take(80).trim()
        return if (limpio.isEmpty()) BASE else "$limpio $BASE"
    }

    fun urlDeBusqueda(texto: String): String =
        "https://www.youtube.com/results?search_query=" + URLEncoder.encode(consulta(texto), "UTF-8") + "&sp=" + FILTRO

    /** Minusculas y sin acentos, para comparar "Completa", "COMPLETA" y "Cómpleta" igual. */
    fun normalizar(s: String): String = RE_ACENTOS.replace(Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD), "")

    internal fun numero(o: JSONObject, clave: String): Double? {
        val v = o.opt(clave)
        return when {
            v == null || v == JSONObject.NULL -> null
            v is Number -> v.toDouble()
            else -> v.toString().toDoubleOrNull()
        }
    }

    internal fun texto(o: JSONObject, clave: String): String {
        val v = o.opt(clave)
        return if (v == null || v == JSONObject.NULL) "" else v.toString().trim()
    }

    /** Se queda con lo que dura mas de 60 minutos y se anuncia como "completa". Sin repetidos. */
    fun filtrar(entradas: JSONArray?, vistos: MutableSet<String>): List<Video> {
        val salida = ArrayList<Video>()
        if (entradas == null) return salida
        for (i in 0 until entradas.length()) {
            val e = entradas.optJSONObject(i) ?: continue
            val id = texto(e, "id")
            if (!RE_ID.matches(id) || id in vistos) continue
            val duracion = numero(e, "duration") ?: continue          // sin duracion = en vivo o dato raro
            if (duracion <= MIN_SEGUNDOS) continue
            val titulo = texto(e, "title")
            if (titulo.isEmpty() || !normalizar(titulo).contains("complet")) continue
            val canal = texto(e, "channel").ifEmpty { texto(e, "uploader") }
            val vistas = numero(e, "view_count")?.toLong() ?: 0L
            vistos.add(id)
            salida.add(Video("yt", id, titulo.take(MAX_TITULO), canal.take(80), duracion.toLong(), vistas))
        }
        return salida
    }
}
