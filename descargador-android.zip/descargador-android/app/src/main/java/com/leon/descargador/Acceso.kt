package com.leon.descargador

/**
 * Usuario y contrasena para entrar a la app.
 * Para cambiarlos, edita estas dos lineas y vuelve a compilar el APK.
 *
 * Es un acceso simple: evita que alguien abra la app por error o curiosidad, pero no es seguridad
 * fuerte (las claves viajan dentro del APK).
 */
object Acceso {
    private const val USUARIO = "Aldo"
    private const val CLAVE = "Aldo"

    /** El usuario no distingue mayusculas (el teclado suele poner la primera en mayuscula); la contrasena si. */
    fun valido(usuario: String, clave: String): Boolean =
        usuario.trim().equals(USUARIO, ignoreCase = true) && clave == CLAVE
}
